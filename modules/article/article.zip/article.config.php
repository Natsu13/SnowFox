<?php
$modules["article"] = array(
					"Name" 		=> "Stránka články",
					"Code_name"	=> "article"
				);